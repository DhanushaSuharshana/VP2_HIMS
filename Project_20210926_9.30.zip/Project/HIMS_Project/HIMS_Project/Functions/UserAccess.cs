﻿using HIMS_Project.PL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HIMS_Project.Functions
{
    public class UserAccess
    {
        #region Dashboard User Access
        // Grant user Priviledgers to Dashboard
        ////public static void UserAccessControl(int UserRole)
        ////{
        ////    Dashboard _dashboard = new Dashboard();

        ////    if (UserRole == 2)
        ////    {
        ////        _dashboard.btnReference.Hide();
        ////    }
        ////    else if (UserRole == 3)
        ////    {

        ////    }
        ////    else if (UserRole == 4)
        ////    {

        ////    }
        ////}
        #endregion Dashboard User Access
    }
}
