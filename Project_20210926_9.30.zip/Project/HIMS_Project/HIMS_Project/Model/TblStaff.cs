﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HIMS_Project.Model
{
    class TblStaff
    {
        public string StaffId { get; set; }
        public string StaffEmail { get; set; }
        public string JoinDate { get; set; }
        public string Photograph { get; set; }
        public string Attachment { get; set; }
        public string SpecialityArea { get; set; }
    }
}
