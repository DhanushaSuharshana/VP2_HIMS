﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HIMS_Project.BLL
{
    class TblStaff_BLL
    {
        #region User Profile
        // Fetch All Logginned User staff details to user profile form


        #endregion User Profile
    }
}
